package code;

/**
 * Class ArcadeDemo
 * This class contains demos of many of the things you might
 * want to use to make an animated arcade game.
 * 
 * Adapted from the AppletAE demo from years past. 
 */

import java.awt.Graphics;
import java.awt.Image;
import java.awt.Color;
import java.awt.Font;
import java.awt.Toolkit;
import java.awt.event.MouseEvent;
import java.awt.event.KeyEvent;
import java.util.ArrayList;
import javax.sound.sampled.Clip;


public class ArcadeDemo extends AnimationPanel 
{
    ArrayList<ArrayList<Location>> grid = new ArrayList<ArrayList<Location>>();
    int frameNumber = 0;
    
    int score = 0;
    ArrayList<LTetrino> tetrinos = new ArrayList<LTetrino>();
    LTetrino current;
    //Constructor
    //-------------------------------------------------------
    public ArcadeDemo()
    {   //Enter the name and width and height.  
        
        super("ArcadeDemo", 700+23, 1000+57);
        ArrayList<Location> tempArray = new ArrayList<>();
       for(int i =0; i<20; i++){
           tempArray = new ArrayList<>();
        for(int j = 0; j<10; j++){
            tempArray.add(new Location(j,i));
        }
        grid.add(tempArray);
       }
       int random;
       for(int i =0; i<5; i++){
        random = (int) Math.round(Math.random()*6);
        
        switch(random){
            case 0:
           
            tetrinos.add(new LTetrino(300, 0));
            break;
            case 1:
            
            tetrinos.add(new LineTetrino(300, 0));
            break;
            case 2:
            
            tetrinos.add(new BLTetrino(300, 0));
            break;
            case 3:
            
            tetrinos.add(new LZigTetrino(300, 0));
            break;
            case 4:
            
            tetrinos.add(new OrangeTetrino(300, 0));
            break;
            case 5:
            
            tetrinos.add(new RZigTetrino(300, 0));
            break;
            case 6:
            
            tetrinos.add(new SquareTetrino(300, 0));
            break;

        
        }
       }
       current = tetrinos.get(0);
       tetrinos.remove(0);
       random = (int) Math.round(Math.random()*1);
        
       switch(random){
        case 0:
       
        tetrinos.add(new LTetrino(300, 0));
        break;
        case 1:
        
        tetrinos.add(new LineTetrino(300, 0));
        break;
        case 2:
        
        tetrinos.add(new BLTetrino(300, 0));
        break;
        case 3:
        
        tetrinos.add(new LZigTetrino(300, 0));
        break;
        case 4:
        
        tetrinos.add(new OrangeTetrino(300, 0));
        break;
        case 5:
        
        tetrinos.add(new RZigTetrino(300, 0));
        break;
        case 6:
        
        tetrinos.add(new SquareTetrino(300, 0));
        break;

    
    }
       
       
    }
    
    
    int counter = 0;
    //The renderFrame method is the one which is called each time a frame is drawn.
    //-------------------------------------------------------
    protected void renderFrame(Graphics g) 
    {   frameNumber ++;
        //draws background
        
        if(current.frozen){
            grid.get(current.hitBox1.y/50).get((current.hitBox1.x-100)/50).colour=current.colour;
            grid.get(current.hitBox1.y/50).get((current.hitBox1.x-100)/50).filled=true;
            grid.get(current.hitBox2.y/50).get((current.hitBox2.x-100)/50).colour=current.colour;
            grid.get(current.hitBox2.y/50).get((current.hitBox2.x-100)/50).filled=true;
            grid.get(current.hitBox3.y/50).get((current.hitBox3.x-100)/50).colour=current.colour;
            grid.get(current.hitBox3.y/50).get((current.hitBox3.x-100)/50).filled=true;
            grid.get(current.hitBox4.y/50).get((current.hitBox4.x-100)/50).colour=current.colour;
            grid.get(current.hitBox4.y/50).get((current.hitBox4.x-100)/50).filled=true;
            
        
        current =tetrinos.get(0);
        tetrinos.remove(0);
         int random = (int) Math.round(Math.random()*6);
         switch(random){
            case 0:
           
            tetrinos.add(new LTetrino(300, 0));
            break;
            case 1:
            
            tetrinos.add(new LineTetrino(300, 0));
            break;
            case 2:
            
            tetrinos.add(new BLTetrino(300, 0));
            break;
            case 3:
            
            tetrinos.add(new LZigTetrino(300, 0));
            break;
            case 4:
            
            tetrinos.add(new OrangeTetrino(300, 0));
            break;
            case 5:
            
            tetrinos.add(new RZigTetrino(300, 0));
            break;
            case 6:
            
            tetrinos.add(new SquareTetrino(300, 0));
            break;

        
        }
        }
        for(int i = 0; i<20; i++){
            counter = 0;
            for(int j =0; j<10; j++){
               
              if(grid.get(i).get(j).filled){
                counter++;
              }
              if(counter==10){
                ArrayList<Location> emptyRow = new ArrayList<Location>();
                for(int f =0; f<10;f++){
                    emptyRow.add(new Location(f,0));
                           }
                  score+=1000;
                grid.remove(i);
                grid.add(0, emptyRow);
                for(int b = 0; b<20; b++){
                    for(int n =0; n<10; n++){
                        grid.get(b).get(n).changeLocation(b, n);
                    }
                }

            }
                
            }
        }
        g.setColor(Color.BLACK);
        g.fillRect(0,0, 703,1003);
        for(int i = 0; i<20; i++){
            for(int j =0; j<10; j++){
              
                g.setColor(grid.get(i).get(j).colour);
                g.fillRect((j+2)*50, i*50, 50, 50);
            }
        }
        g.setColor(Color.WHITE);
        for(int i =0; i<9; i++){
            g.drawRect(50*i+100, 0, 50, 1000);
        }
        for(int i = 0; i<20; i++){
            g.drawRect(100, 50*i+1, 500, 50);
        }
        if(frameNumber%60 == 0){
            
            current.animate();
            
            if(!current.inBounds(this)){
                current.unanimate();
            current.frozen = true;
            }
            
        } 
        current.draw(g);
        g.setFont(new Font("Courier",Font.BOLD,23));
        g.drawString("Score:", 0, 100);
        g.drawString(score+"", 0, 120);
        
        

    }//--end of renderFrame method--
    
    //-------------------------------------------------------
    //Respond to Mouse Events
    //-------------------------------------------------------
    public void mouseClicked(MouseEvent e)  
    { 
        
    }
    
    //-------------------------------------------------------
    //Respond to Keyboard Events
    //-------------------------------------------------------
    public void keyTyped(KeyEvent e) 
    {
        char c = e.getKeyChar();
       
        if(c == 'd' || c == 'D' ){
            current.moveRight();
            if(!current.inBounds(this)){
                current.moveLeft();
            }
        }
        if(c == 'a' || c == 'A' ){
            current.moveLeft();
            if(!current.inBounds(this)){
                current.moveRight();
            }

        }
        if(c == 's' || c == 'S'){
            current.animate();
            
            if(!current.inBounds(this)){
                current.unanimate();
            current.frozen = true;
            }
        }

    }
    
    public void keyPressed(KeyEvent e)
    {
        int v = e.getKeyCode();
        if(v == KeyEvent.VK_SHIFT){
        current.rotateF();
            if(!current.inBounds(this))
            current.rotateB();

        }
        
        
    }

    public void keyReleased(KeyEvent e)
    {
        int v = e.getKeyCode();
        
       
    }
    
    
    //-------------------------------------------------------
    //Initialize Graphics
    //-------------------------------------------------------
//-----------------------------------------------------------------------
/*  Image section... 
 *  To add a new image to the program, do three things.
 *  1.  Make a declaration of the Image by name ...  Image imagename;
 *  2.  Actually make the image and store it in the same directory as the code.
 *  3.  Add a line into the initGraphics() function to load the file. 
//-----------------------------------------------------------------------*/
    Image ballImage;        
    Image starImage;
    
    public void initGraphics() 
    {      
        Toolkit toolkit = Toolkit.getDefaultToolkit();
        
        
    } //--end of initGraphics()--
    
    //-------------------------------------------------------
    //Initialize Sounds
    //-------------------------------------------------------
//-----------------------------------------------------------------------
/*  Music section... 
 *  To add music clips to the program, do four things.
 *  1.  Make a declaration of the AudioClip by name ...  AudioClip clipname;
 *  2.  Actually make/get the .wav file and store it in the same directory as the code.
 *  3.  Add a line into the initMusic() function to load the clip. 
 *  4.  Use the play(), stop() and loop() functions as needed in your code.
//-----------------------------------------------------------------------*/
    Clip themeMusic;
    Clip bellSound;
    
    public void initMusic() 
    {
        themeMusic = loadClip("src/audio/theme.wav");
        bellSound = loadClip("src/audio/ding.wav");
        if(themeMusic != null)
//            themeMusic.start(); //This would make it play once!
            themeMusic.loop(20); //This would make it loop 2 times.
    }

//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
}//--end of ArcadeDemo class--

