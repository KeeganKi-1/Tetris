package code;


import java.awt.Color;
import java.awt.Graphics;
import java.awt.Point;
import java.awt.Rectangle;
import java.util.Random;

public class LTetrino {
    boolean frozen;
    int phase = 1;
    int xCoord;
    int yCoord;
    HitBox hitBox1;
    HitBox hitBox2;
    HitBox hitBox3;
    HitBox hitBox4;
    int width;
    Color colour = new Color(2,46,24);
    public LTetrino(int x, int y){
        xCoord = x;
        yCoord = y;
        updateHitbox();
        
    }

    public void moveRight(){
        if(!frozen){
        
        xCoord+=50;
        updateHitbox();
    }
    }

    public void moveLeft(){
        if(!frozen){
        if(xCoord>100){
        xCoord-=50;
        }
        updateHitbox();
        
    }
    }
    

    public boolean inBounds(ArcadeDemo demo){
        
        try {
        if((!((hitBox1.x<600 && hitBox1.x>=100) && (hitBox1.y<=1000)))||(demo.grid.get(hitBox1.y/50).get((hitBox1.x-100)/50).filled)){
            return false;
        }
        else if(!((hitBox2.x<600 && hitBox2.x>=100) && (hitBox2.y<=1000))||(demo.grid.get(hitBox2.y/50).get((hitBox2.x-100)/50).filled)){
            return false;
        }
        else if(!((hitBox3.x<600 && hitBox3.x>=100) && (hitBox3.y<=1000))||(demo.grid.get(hitBox3.y/50).get((hitBox3.x-100)/50).filled)){
            return false;
        }
        else if(!((hitBox4.x<600 && hitBox4.x>=100) && (hitBox4.y<=1000))||(demo.grid.get(hitBox4.y/50).get((hitBox4.x-100)/50).filled)){
            return false;
        }
    }
        catch (Exception e) {
            if((!((hitBox1.x<600 && hitBox1.x>=100)))){
                return false;
            }
            else if(!((hitBox2.x<600 && hitBox2.x>=100))){
                return false;
            }
            else if(!((hitBox3.x<600 && hitBox3.x>=100))){
                return false;
            }
            else if(!((hitBox4.x<600 && hitBox4.x>=100))){
                return false;
            }
           
        }
        return true;
    }

    public void animate(){

        if(yCoord<950) 
        yCoord += 50;
        else{
            frozen = true;
        }
        updateHitbox();
    }
    public void unanimate(){
        yCoord -=50;
        updateHitbox();
    }
    public void updateHitbox(){
        if(phase ==1){
            
            hitBox1 = new HitBox(xCoord, yCoord);
            hitBox2 = new HitBox(xCoord, yCoord-50);
            hitBox3 = new HitBox(xCoord, yCoord-100);
            hitBox4 = new HitBox(xCoord+50,yCoord); 
        }
        else if(phase ==2){
            
            hitBox1 = new HitBox(xCoord, yCoord);
            hitBox2 = new HitBox(xCoord, yCoord-50);
            hitBox3 = new HitBox(xCoord+50, yCoord-50);
            hitBox4 = new HitBox(xCoord+100,yCoord-50);
        }
        else if(phase ==3){
            
            hitBox1 = new HitBox(xCoord, yCoord);
            hitBox2 = new HitBox(xCoord, yCoord-50);
            hitBox3 = new HitBox(xCoord, yCoord-100);
            hitBox4 = new HitBox(xCoord-50,yCoord-100);
        }
        else if(phase ==4){
            
            hitBox1 = new HitBox(xCoord, yCoord);
            hitBox2 = new HitBox(xCoord+50, yCoord);
            hitBox3 = new HitBox(xCoord+100, yCoord);
            hitBox4 = new HitBox(xCoord+100,yCoord-50);
        }
    }
    public void rotateF(){
        if(!frozen){
        phase++;
        
        if(phase == 5)
        phase =1;
       updateHitbox();
    }
    }
    public void rotateB(){
        if(!frozen){
        phase--;
        if(phase == 0)
        phase =4;
       updateHitbox();
    }
    }

    public void draw(Graphics g){
        if(!frozen){
        if(phase ==1){
        g.setColor(new Color(2,46,24));
        g.fillRect(xCoord, yCoord, 50, 50);
        g.fillRect(xCoord, yCoord-50, 50, 50);
        g.fillRect(xCoord, yCoord-100, 50, 50);
        g.fillRect(xCoord+50, yCoord, 50, 50);
        
        hitBox1 = new HitBox(xCoord, yCoord);
        hitBox2 = new HitBox(xCoord, yCoord-50);
        hitBox3 = new HitBox(xCoord, yCoord-100);
        hitBox4 = new HitBox(xCoord+50,yCoord);

        g.setColor(Color.WHITE);
        g.drawRect(xCoord, yCoord, 50, 50);
        g.drawRect(xCoord, yCoord-50, 50, 50);
        g.drawRect(xCoord, yCoord-100, 50, 50);
        g.drawRect(xCoord+50, yCoord, 50, 50);
        }
        if(phase == 2){
            g.setColor(new Color(2,46,24));
            g.fillRect(xCoord, yCoord, 50, 50);
            g.fillRect(xCoord, yCoord-50, 50, 50);
            g.fillRect(xCoord+50, yCoord-50, 50, 50);
            g.fillRect(xCoord+100, yCoord-50, 50, 50);
            
        hitBox1 = new HitBox(xCoord, yCoord);
        hitBox2 = new HitBox(xCoord, yCoord-50);
        hitBox3 = new HitBox(xCoord+50, yCoord-50);
        hitBox4 = new HitBox(xCoord+100,yCoord-50);
    
            g.setColor(Color.WHITE);
            g.drawRect(xCoord, yCoord, 50, 50);
            g.drawRect(xCoord, yCoord-50, 50, 50);
            g.drawRect(xCoord+50, yCoord-50, 50, 50);
            g.drawRect(xCoord+100, yCoord-50, 50, 50);
        }
        if(phase == 3){
            g.setColor(new Color(2,46,24));
            g.fillRect(xCoord, yCoord, 50, 50);
            g.fillRect(xCoord, yCoord-50, 50, 50);
            g.fillRect(xCoord, yCoord-100, 50, 50);
            g.fillRect(xCoord-50, yCoord-100, 50, 50);
            
        hitBox1 = new HitBox(xCoord, yCoord);
        hitBox2 = new HitBox(xCoord, yCoord-50);
        hitBox3 = new HitBox(xCoord, yCoord-100);
        hitBox4 = new HitBox(xCoord-50,yCoord-100);
    
            g.setColor(Color.WHITE);
            g.drawRect(xCoord, yCoord, 50, 50);
            g.drawRect(xCoord, yCoord-50, 50, 50);
            g.drawRect(xCoord, yCoord+-100, 50, 50);
            g.drawRect(xCoord+-50, yCoord-100, 50, 50);
        }
        if(phase == 4){
            g.setColor(new Color(2,46,24));
            g.fillRect(xCoord, yCoord, 50, 50);
            g.fillRect(xCoord+50, yCoord, 50, 50);
            g.fillRect(xCoord+100, yCoord, 50, 50);
            g.fillRect(xCoord+100, yCoord-50, 50, 50);
            
        hitBox1 = new HitBox(xCoord, yCoord);
        hitBox2 = new HitBox(xCoord+50, yCoord);
        hitBox3 = new HitBox(xCoord+100, yCoord);
        hitBox4 = new HitBox(xCoord+100,yCoord-50);
    
            g.setColor(Color.WHITE);
            g.drawRect(xCoord, yCoord, 50, 50);
            g.drawRect(xCoord+50, yCoord, 50, 50);
            g.drawRect(xCoord+100, yCoord, 50, 50);
            g.drawRect(xCoord+100, yCoord-50, 50, 50);
        }
    }
    }

}
