package code;


import java.awt.Color;
import java.awt.Graphics;
import java.awt.Point;
import java.awt.Rectangle;
import java.util.Random;

public class OrangeTetrino extends LTetrino{

    public OrangeTetrino(int x, int y) {
    super(x, y);
    colour = new Color(138,102,34);
    }

    @Override
    public void updateHitbox(){
        if(phase ==1){
            
            hitBox1 = new HitBox(xCoord, yCoord);
            hitBox2 = new HitBox(xCoord, yCoord-50);
            hitBox3 = new HitBox(xCoord, yCoord-100);
            hitBox4 = new HitBox(xCoord+50,yCoord-50); 
        }
        else if(phase ==2){
            
            hitBox1 = new HitBox(xCoord, yCoord);
            hitBox2 = new HitBox(xCoord+50, yCoord-50);
            hitBox3 = new HitBox(xCoord-50, yCoord-50);
            hitBox4 = new HitBox(xCoord,yCoord-50);
        }
        else if(phase ==3){
            hitBox1 = new HitBox(xCoord, yCoord);
            hitBox2 = new HitBox(xCoord, yCoord-50);
            hitBox3 = new HitBox(xCoord, yCoord-100);
            hitBox4 = new HitBox(xCoord-50,yCoord-50); 
        }
        else if(phase ==4){
            
            hitBox1 = new HitBox(xCoord, yCoord);
            hitBox2 = new HitBox(xCoord+50, yCoord);
            hitBox3 = new HitBox(xCoord+100, yCoord);
            hitBox4 = new HitBox(xCoord+50,yCoord-50);
        }
    }

    @Override
    public void draw(Graphics g){
updateHitbox();

if(phase ==1){
    g.setColor(colour);
    g.fillRect(xCoord, yCoord, 50, 50);
    g.fillRect(xCoord, yCoord-50, 50, 50);
    g.fillRect(xCoord, yCoord-100, 50, 50);
    g.fillRect(xCoord+50, yCoord-50, 50, 50);

    g.setColor(Color.WHITE);
    g.drawRect(xCoord, yCoord, 50, 50);
    g.drawRect(xCoord, yCoord-50, 50, 50);
    g.drawRect(xCoord, yCoord-100, 50, 50);
    g.drawRect(xCoord+50, yCoord-50, 50, 50);

    
}
if(phase ==2){
    g.setColor(colour);
    g.fillRect(xCoord, yCoord, 50, 50);
    g.fillRect(xCoord+50, yCoord-50, 50, 50);
    g.fillRect(xCoord-50, yCoord-50, 50, 50);
    g.fillRect(xCoord, yCoord-50, 50, 50);

    g.setColor(Color.WHITE);
    g.drawRect(xCoord, yCoord, 50, 50);
    g.drawRect(xCoord+50, yCoord-50, 50, 50);
    g.drawRect(xCoord-50, yCoord-50, 50, 50);
    g.drawRect(xCoord, yCoord-50, 50, 50);
}
if(phase ==3){
    g.setColor(colour);
    g.fillRect(xCoord, yCoord, 50, 50);
    g.fillRect(xCoord, yCoord-50, 50, 50);
    g.fillRect(xCoord, yCoord-100, 50, 50);
    g.fillRect(xCoord-50, yCoord-50, 50, 50);

    g.setColor(Color.WHITE);
    g.drawRect(xCoord, yCoord, 50, 50);
    g.drawRect(xCoord, yCoord-50, 50, 50);
    g.drawRect(xCoord, yCoord-100, 50, 50);
    g.drawRect(xCoord-50, yCoord-50, 50, 50);
}
if(phase ==4){
    g.setColor(colour);
    g.fillRect(xCoord, yCoord, 50, 50);
    g.fillRect(xCoord+50, yCoord, 50, 50);
    g.fillRect(xCoord+100, yCoord, 50, 50);
    g.fillRect(xCoord+50, yCoord-50, 50, 50);

    g.setColor(Color.WHITE);
    g.drawRect(xCoord, yCoord, 50, 50);
    g.drawRect(xCoord+50, yCoord, 50, 50);
    g.drawRect(xCoord+100, yCoord, 50, 50);
    g.drawRect(xCoord+50, yCoord-50, 50, 50);
}

    }

}