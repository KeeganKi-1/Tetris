package code;


import java.awt.Color;
import java.awt.Graphics;
import java.awt.Point;
import java.awt.Rectangle;
import java.util.Random;

public class SquareTetrino extends LTetrino{

    public SquareTetrino(int x, int y) {
    super(x, y);
    colour = new Color(184,175,6);
    }

    @Override
    public void updateHitbox(){
        if(phase ==1){
            
            hitBox1 = new HitBox(xCoord, yCoord);
            hitBox2 = new HitBox(xCoord, yCoord-50);
            hitBox3 = new HitBox(xCoord+50, yCoord-50);
            hitBox4 = new HitBox(xCoord+50,yCoord); 
        }
        else if(phase ==2){
            hitBox1 = new HitBox(xCoord, yCoord);
            hitBox2 = new HitBox(xCoord, yCoord-50);
            hitBox3 = new HitBox(xCoord+50, yCoord-50);
            hitBox4 = new HitBox(xCoord+50,yCoord); 
        }
        else if(phase ==3){
            hitBox1 = new HitBox(xCoord, yCoord);
            hitBox2 = new HitBox(xCoord, yCoord-50);
            hitBox3 = new HitBox(xCoord+50, yCoord-50);
            hitBox4 = new HitBox(xCoord+50,yCoord); 
        }
        else if(phase ==4){
            
            hitBox1 = new HitBox(xCoord, yCoord);
            hitBox2 = new HitBox(xCoord, yCoord-50);
            hitBox3 = new HitBox(xCoord+50, yCoord-50);
            hitBox4 = new HitBox(xCoord+50,yCoord); 
        }
    }

    @Override
    public void draw(Graphics g){
updateHitbox();

if(phase ==1){
    g.setColor(colour);
    g.fillRect(xCoord, yCoord, 50, 50);
    g.fillRect(xCoord, yCoord-50, 50, 50);
    g.fillRect(xCoord+50, yCoord-50, 50, 50);
    g.fillRect(xCoord+50, yCoord, 50, 50);

    g.setColor(Color.WHITE);
    g.drawRect(xCoord, yCoord, 50, 50);
    g.drawRect(xCoord, yCoord-50, 50, 50);
    g.drawRect(xCoord+50, yCoord-50, 50, 50);
    g.drawRect(xCoord+50, yCoord, 50, 50);

    
}
if(phase ==2){
    g.setColor(colour);
    g.fillRect(xCoord, yCoord, 50, 50);
    g.fillRect(xCoord, yCoord-50, 50, 50);
    g.fillRect(xCoord+50, yCoord-50, 50, 50);
    g.fillRect(xCoord+50, yCoord, 50, 50);

    g.setColor(Color.WHITE);
    g.drawRect(xCoord, yCoord, 50, 50);
    g.drawRect(xCoord, yCoord-50, 50, 50);
    g.drawRect(xCoord+50, yCoord-50, 50, 50);
    g.drawRect(xCoord+50, yCoord, 50, 50);
}
if(phase ==3){
    g.setColor(colour);
    g.fillRect(xCoord, yCoord, 50, 50);
    g.fillRect(xCoord, yCoord-50, 50, 50);
    g.fillRect(xCoord+50, yCoord-50, 50, 50);
    g.fillRect(xCoord+50, yCoord, 50, 50);

    g.setColor(Color.WHITE);
    g.drawRect(xCoord, yCoord, 50, 50);
    g.drawRect(xCoord, yCoord-50, 50, 50);
    g.drawRect(xCoord+50, yCoord-50, 50, 50);
    g.drawRect(xCoord+50, yCoord, 50, 50);
}
if(phase ==4){
    g.setColor(colour);
    g.fillRect(xCoord, yCoord, 50, 50);
    g.fillRect(xCoord, yCoord-50, 50, 50);
    g.fillRect(xCoord+50, yCoord-50, 50, 50);
    g.fillRect(xCoord+50, yCoord, 50, 50);

    g.setColor(Color.WHITE);
    g.drawRect(xCoord, yCoord, 50, 50);
    g.drawRect(xCoord, yCoord-50, 50, 50);
    g.drawRect(xCoord+50, yCoord-50, 50, 50);
    g.drawRect(xCoord+50, yCoord, 50, 50);
}

    }

}